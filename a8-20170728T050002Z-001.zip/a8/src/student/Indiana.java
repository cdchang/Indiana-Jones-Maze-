package student;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import game.ScramState;
import game.Tile;
import game.HuntState;
import game.Explorer;
import game.Node;
import game.NodeStatus;
import student.Paths;

public class Indiana extends Explorer {

	private long startTime= 0;    // start time in milliseconds 
	private HashSet visited = null; // HashSet containing all ids of tiles that have been visited during dfs

	/** Get to the orb in as few steps as possible. Once you get there, 
	 * you must return from the function in order to pick
	 * it up. If you continue to move after finding the orb rather 
	 * than returning, it will not count.
	 * If you return from this function while not standing on top of the orb, 
	 * it will count as a failure.
	 * 
	 * There is no limit to how many steps you can take, but you will receive
	 * a score bonus multiplier for finding the orb in fewer steps.
	 * 
	 * At every step, you know only your current tile's ID and the ID of all 
	 * open neighbor tiles, as well as the distance to the orb at each of these tiles
	 * (ignoring walls and obstacles). 
	 * 
	 * In order to get information about the current state, use functions
	 * currentLocation(), neighbors(), and distanceToOrb() in HuntState.
	 * You know you are standing on the orb when distanceToOrb() is 0.
	 * 
	 * Use function moveTo(long id) in HuntState to move to a neighboring 
	 * tile by its ID. Doing this will change state to reflect your new position.
	 * 
	 * A suggested first implementation that will always find the orb, but likely won't
	 * receive a large bonus multiplier, is a depth-first search. Some
	 * modification is necessary to make the search better, in general.*/

	@Override public void huntOrb(HuntState state) {
		visited = new HashSet<Long>();
		if (state.distanceToOrb() !=0){
			// get neighbor set + do dfs through each of them till orb is found
			dfs(state.currentLocation(), state); // finds the path and moves in the process
		}
	}

	/** 
	 * This method implements a dfs. Given a location, the method moves Indiana to that location and then recursively 
	 * calls dfs on the neighbors in order of highest priority (highest priority --> smallest Manhattan distance). As
	 * the dfs is conducted, Indiana moves on the GUI and moves back in the case that it cannot find the orb. The 
	 * method returns either when the orb has been found or if the dfs results in not being able to find the orb.
	 */

	public void dfs(Long id, HuntState state){
		Heap<NodeStatus> neighbors = new Heap<NodeStatus>(); // neighbors of current node

		long previousId = state.currentLocation(); //starting loc

		if (!visited.contains(id)){ 
			visited.add(id); 
		}

		if (id != previousId && (state.distanceToOrb() != 0))
			state.moveTo(id); //if not on starting location, then move

		if (state.distanceToOrb() == 0) return; 

		for (NodeStatus ns: state.neighbors()) { //put all the nodestatus ids into a heap

			if (state.distanceToOrb() == 0) return; 

			if (!visited.contains(ns.getId())) 
				neighbors.add(ns, ns.getDistanceToTarget()); 
		}

		// while there are neighbors, go through each of them to find orb 
		while (neighbors.size != 0) { 
			long pNode = neighbors.poll().getId(); //retrieve shortest manhattan distance neighbor
			if (!visited.contains(pNode)) {
				dfs(pNode, state); 
			}
		}

		if (state.distanceToOrb() != 0) 
			state.moveTo(previousId); 
	}

	/** 
	 * Get out the cavern before the ceiling collapses, trying to collect as much
	 * gold as possible along the way. Your solution must ALWAYS get out before time runs
	 * out, and this should be prioritized above collecting gold.
	 * 
	 * You now have access to the entire underlying graph, which can be accessed through ScramState.
	 * currentNode() and getExit() will return Node objects of interest, and getNodes()
	 * will return a collection of all nodes on the graph. 
	 * 
	 * Note that the cavern will collapse in the number of steps given by getStepsRemaining(),
	 * and for each step this number is decremented by the weight of the edge taken. You can use
	 * getStepsRemaining() to get the time still remaining, pickUpGold() to pick up any gold
	 * on your current tile (this will fail if no such gold exists), and moveTo() to move
	 * to a destination node adjacent to your current node.
	 * 
	 * You must return from this function while standing at the exit. Failing to do so before time
	 * runs out or returning from the wrong location will be considered a failed run.
	 * 
	 * You will always have enough time to escape using the shortest path from the starting
	 * position to the exit, although this will not collect much gold. For this reason, using 
	 * Dijkstra's to plot the shortest path to the exit is a good starting solution    
	 */

	@Override public void scram(ScramState state) {
		List<Node> path = Paths.shortestPath(state.currentNode(), state.getExit()); //initial shortest path

		// get all the nodes / tiles. order them in a min heap: (MAX_INTEGER - tile gold value) for each element
		//poll from the heap and go down shortest path from currentLoc to the node that was being polled
		//if (steps remaining = steps to exit) go directly to the exit

		Set<Node> allTiles = (Set<Node>) state.allNodes(); //get all the nodes
		Heap<Node> orderedTiles = new Heap<Node>(); // min heap ordering nodes where root node has the most gold

		for (Node n: allTiles) 
			orderedTiles.add(n, Integer.MAX_VALUE - n.getTile().gold());

		// while path length doesn't exceed the steps left, look for optimized path to get most gold
		while (state.stepsLeft() > Paths.pathDistance(path) && (Paths.pathDistance(path) != 0)) { 

			if (orderedTiles.size() > 0) { 
				Node maxGoldTile = orderedTiles.poll(); 

				if (maxGoldTile.getTile().gold() != 0){ //if maxGoldTile hasn't previously been touched

					List<Node> goldPath = Paths.shortestPath(state.currentNode(), maxGoldTile);

					int dist = Paths.pathDistance((List<Node>) goldPath) + Paths.pathDistance(Paths.shortestPath(maxGoldTile, state.getExit()));

					// if it's possible to move to maxGoldNode and get to exit from the maxGoldNode, go through path
					if (dist < state.stepsLeft()) {

						for (Node n: goldPath) {
							if (state.currentNode().getTile().gold() > 0)  
								state.grabGold();

							if (state.currentNode() != n)
								state.moveTo(n);
						}
					}
				} 
			} else if (orderedTiles.size()==0) // if no more tiles with gold
				break;

			path = Paths.shortestPath(state.currentNode(), state.getExit());
		}

		for (Node n: path) { // going down shortest path to the exit
			if (state.currentNode().getTile().gold()>0)
				state.grabGold();

			if (state.currentNode().getNeighbors().contains(n))
				state.moveTo(n);
		}
	}
}
